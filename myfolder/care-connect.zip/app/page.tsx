"use client"

import { useState } from "react"
import Navigation from "@/components/navigation"
import Dashboard from "@/components/dashboard"
import UserProfile from "@/components/user-profile"
import DoctorDirectory from "@/components/doctor-directory"
import AppointmentBooking from "@/components/appointment-booking"
import SymptomChatbot from "@/components/symptom-chatbot"
import LabReportUpload from "@/components/lab-report-upload"
import HealthReminders from "@/components/health-reminders"
import HealthDiary from "@/components/health-diary"
import DoctorConnection from "@/components/doctor-connection"

export default function Home() {
  const [currentPage, setCurrentPage] = useState("dashboard")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  if (!isLoggedIn) {
    return <UserProfile onLoginSuccess={() => setIsLoggedIn(true)} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-blue-100 to-cyan-50">
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />

      <main className="pt-20 pb-8">
        {currentPage === "dashboard" && <Dashboard />}
        {currentPage === "doctors" && <DoctorDirectory />}
        {currentPage === "appointments" && <AppointmentBooking />}
        {currentPage === "chatbot" && <SymptomChatbot />}
        {currentPage === "lab-reports" && <LabReportUpload />}
        {currentPage === "reminders" && <HealthReminders />}
        {currentPage === "diary" && <HealthDiary />}
        {currentPage === "connect-doctor" && <DoctorConnection />}
      </main>
    </div>
  )
}
