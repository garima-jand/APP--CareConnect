"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Star, MapPin, Phone } from "lucide-react"

export default function DoctorDirectory() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSpecialty, setSelectedSpecialty] = useState("all")

  const doctors = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      specialty: "Cardiology",
      distance: "2.5 km",
      rating: 4.8,
      reviews: 245,
      phone: "+1 (555) 123-4567",
      image: "/professional-female-doctor-cardiology.jpg",
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      specialty: "Neurology",
      distance: "3.2 km",
      rating: 4.9,
      reviews: 312,
      phone: "+1 (555) 234-5678",
      image: "/professional-male-doctor-neurology.jpg",
    },
    {
      id: 3,
      name: "Dr. Emily Rodriguez",
      specialty: "Pediatrics",
      distance: "1.8 km",
      rating: 4.7,
      reviews: 189,
      phone: "+1 (555) 345-6789",
      image: "/professional-female-doctor-pediatrics.jpg",
    },
    {
      id: 4,
      name: "Dr. James Wilson",
      specialty: "Orthopedics",
      distance: "4.1 km",
      rating: 4.6,
      reviews: 267,
      phone: "+1 (555) 456-7890",
      image: "/professional-male-doctor-orthopedics.jpg",
    },
  ]

  const specialties = ["all", "Cardiology", "Neurology", "Pediatrics", "Orthopedics"]

  const filteredDoctors = doctors.filter((doctor) => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSpecialty = selectedSpecialty === "all" || doctor.specialty === selectedSpecialty
    return matchesSearch && matchesSpecialty
  })

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Find Doctors</h2>

      {/* Search and Filter */}
      <div className="mb-8 space-y-4">
        <Input
          type="text"
          placeholder="Search doctors by name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full"
        />

        <div className="flex gap-2 flex-wrap">
          {specialties.map((specialty) => (
            <Button
              key={specialty}
              onClick={() => setSelectedSpecialty(specialty)}
              variant={selectedSpecialty === specialty ? "default" : "outline"}
              className={selectedSpecialty === specialty ? "bg-blue-600" : ""}
            >
              {specialty.charAt(0).toUpperCase() + specialty.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {/* Doctors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredDoctors.map((doctor) => (
          <Card key={doctor.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <img src={doctor.image || "/placeholder.svg"} alt={doctor.name} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="font-bold text-lg text-blue-900 mb-1">{doctor.name}</h3>
              <p className="text-sm text-gray-600 mb-3">{doctor.specialty}</p>

              <div className="flex items-center gap-1 mb-3">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold text-sm">{doctor.rating}</span>
                <span className="text-xs text-gray-500">({doctor.reviews})</span>
              </div>

              <div className="space-y-2 mb-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {doctor.distance}
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  {doctor.phone}
                </div>
              </div>

              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Book Appointment</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
