"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, AlertCircle } from "lucide-react"

export default function SymptomChatbot() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: "bot",
      text: "Hello! I'm your health assistant. Please describe your symptoms, and I'll help you understand what might be causing them.",
    },
  ])
  const [input, setInput] = useState("")

  const symptomDatabase: Record<string, string> = {
    headache:
      "Headaches can be caused by stress, dehydration, or migraines. Consider resting, drinking water, and consulting a doctor if persistent.",
    fever:
      "Fever is often a sign of infection. Stay hydrated, rest, and monitor your temperature. Seek medical attention if it exceeds 103°F.",
    cough:
      "A cough can indicate a cold, flu, or allergies. Use cough drops, stay hydrated, and see a doctor if it persists for more than 2 weeks.",
    "chest pain":
      "Chest pain requires immediate medical attention. Call emergency services or visit the nearest hospital.",
    fatigue:
      "Fatigue can result from poor sleep, stress, or underlying conditions. Ensure adequate rest and consult a doctor if it persists.",
  }

  const handleSendMessage = () => {
    if (!input.trim()) return

    // Add user message
    const userMessage = {
      id: messages.length + 1,
      type: "user",
      text: input,
    }
    setMessages([...messages, userMessage])

    // Generate bot response
    const lowerInput = input.toLowerCase()
    let botResponse =
      "I understand. Based on your symptoms, I recommend consulting with a healthcare professional for a proper diagnosis."

    for (const [symptom, response] of Object.entries(symptomDatabase)) {
      if (lowerInput.includes(symptom)) {
        botResponse = response
        break
      }
    }

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          type: "bot",
          text: botResponse,
        },
      ])
    }, 500)

    setInput("")
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Symptom Checker</h2>

      <Card className="p-6 flex flex-col h-96">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto mb-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-xs px-4 py-2 rounded-lg ${
                  msg.type === "user" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-900"
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Describe your symptoms..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          />
          <Button onClick={handleSendMessage} className="bg-blue-600 hover:bg-blue-700 text-white">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </Card>

      <Card className="mt-6 p-4 bg-yellow-50 border-l-4 border-l-yellow-400">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-yellow-900">Disclaimer</h4>
            <p className="text-sm text-yellow-800">
              This chatbot provides general information only and is not a substitute for professional medical advice.
              Always consult with a qualified healthcare provider for diagnosis and treatment.
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}
