"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Calendar, Clock, CheckCircle } from "lucide-react"

export default function AppointmentBooking() {
  const [appointments, setAppointments] = useState([
    {
      id: 1,
      doctor: "Dr. Sarah Johnson",
      specialty: "Cardiology",
      date: "2025-10-28",
      time: "10:00 AM",
      status: "Confirmed",
      slot: "Slot 1",
    },
    {
      id: 2,
      doctor: "Dr. Michael Chen",
      specialty: "Neurology",
      date: "2025-11-02",
      time: "2:30 PM",
      status: "Pending",
      slot: "Slot 3",
    },
  ])

  const [newAppointment, setNewAppointment] = useState({
    doctor: "",
    date: "",
    time: "",
  })

  const handleBookAppointment = (e: React.FormEvent) => {
    e.preventDefault()
    if (newAppointment.doctor && newAppointment.date && newAppointment.time) {
      const appointment = {
        id: appointments.length + 1,
        doctor: newAppointment.doctor,
        specialty: "General",
        date: newAppointment.date,
        time: newAppointment.time,
        status: "Confirmed",
        slot: `Slot ${Math.floor(Math.random() * 5) + 1}`,
      }
      setAppointments([...appointments, appointment])
      setNewAppointment({ doctor: "", date: "", time: "" })
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Appointment Booking</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Booking Form */}
        <Card className="lg:col-span-1 p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Book New Appointment</h3>
          <form onSubmit={handleBookAppointment} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Doctor Name</label>
              <Input
                type="text"
                placeholder="Enter doctor name"
                value={newAppointment.doctor}
                onChange={(e) => setNewAppointment({ ...newAppointment, doctor: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
              <Input
                type="date"
                value={newAppointment.date}
                onChange={(e) => setNewAppointment({ ...newAppointment, date: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
              <Input
                type="time"
                value={newAppointment.time}
                onChange={(e) => setNewAppointment({ ...newAppointment, time: e.target.value })}
                required
              />
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Book Appointment
            </Button>
          </form>
        </Card>

        {/* Appointments List */}
        <div className="lg:col-span-2">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Your Appointments</h3>
          <div className="space-y-4">
            {appointments.map((apt) => (
              <Card key={apt.id} className="p-4 border-l-4 border-l-blue-600">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-bold text-blue-900">{apt.doctor}</h4>
                    <p className="text-sm text-gray-600">{apt.specialty}</p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      apt.status === "Confirmed" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {apt.status}
                  </span>
                </div>

                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {new Date(apt.date).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    {apt.time}
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    {apt.slot}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
