"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Upload, FileText, QrCode } from "lucide-react"

export default function LabReportUpload() {
  const [reports, setReports] = useState([
    {
      id: 1,
      name: "Blood Test Report",
      date: "2025-10-20",
      status: "Normal",
      values: { hemoglobin: "14.5 g/dL", glucose: "95 mg/dL" },
      qrCode: "QR-001",
    },
    {
      id: 2,
      name: "Cholesterol Panel",
      date: "2025-10-15",
      status: "Alert",
      values: { ldl: "150 mg/dL", hdl: "35 mg/dL" },
      qrCode: "QR-002",
    },
  ])

  const [newReport, setNewReport] = useState({
    name: "",
    date: "",
    file: null as File | null,
  })

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setNewReport({ ...newReport, file: e.target.files[0] })
    }
  }

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault()
    if (newReport.name && newReport.date && newReport.file) {
      const report = {
        id: reports.length + 1,
        name: newReport.name,
        date: newReport.date,
        status: "Pending",
        values: {},
        qrCode: `QR-${String(reports.length + 1).padStart(3, "0")}`,
      }
      setReports([...reports, report])
      setNewReport({ name: "", date: "", file: null })
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Lab Reports</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upload Form */}
        <Card className="lg:col-span-1 p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Upload Report</h3>
          <form onSubmit={handleUpload} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Report Name</label>
              <Input
                type="text"
                placeholder="e.g., Blood Test"
                value={newReport.name}
                onChange={(e) => setNewReport({ ...newReport, name: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
              <Input
                type="date"
                value={newReport.date}
                onChange={(e) => setNewReport({ ...newReport, date: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">File</label>
              <div className="border-2 border-dashed border-blue-300 rounded-lg p-4 text-center cursor-pointer hover:bg-blue-50">
                <input
                  type="file"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-input"
                  accept=".pdf,.jpg,.png"
                />
                <label htmlFor="file-input" className="cursor-pointer">
                  <Upload className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                  <p className="text-sm text-gray-600">{newReport.file ? newReport.file.name : "Click to upload"}</p>
                </label>
              </div>
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Upload Report
            </Button>
          </form>
        </Card>

        {/* Reports List */}
        <div className="lg:col-span-2">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Your Reports</h3>
          <div className="space-y-4">
            {reports.map((report) => (
              <Card key={report.id} className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <FileText className="w-6 h-6 text-blue-600 mt-1" />
                    <div>
                      <h4 className="font-bold text-blue-900">{report.name}</h4>
                      <p className="text-sm text-gray-600">{new Date(report.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      report.status === "Normal"
                        ? "bg-green-100 text-green-700"
                        : report.status === "Alert"
                          ? "bg-red-100 text-red-700"
                          : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {report.status}
                  </span>
                </div>

                {Object.keys(report.values).length > 0 && (
                  <div className="mb-3 p-3 bg-gray-50 rounded">
                    {Object.entries(report.values).map(([key, value]) => (
                      <div key={key} className="text-sm text-gray-600">
                        <span className="font-semibold">{key}:</span> {value}
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2 text-sm text-blue-600">
                  <QrCode className="w-4 h-4" />
                  {report.qrCode}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
