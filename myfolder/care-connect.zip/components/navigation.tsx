"use client"

import { Button } from "@/components/ui/button"
import { Heart, Users, Calendar, MessageSquare, FileText, Bell, BookOpen, Mail, LogOut } from "lucide-react"

interface NavigationProps {
  currentPage: string
  setCurrentPage: (page: string) => void
}

export default function Navigation({ currentPage, setCurrentPage }: NavigationProps) {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: Heart },
    { id: "doctors", label: "Find Doctors", icon: Users },
    { id: "appointments", label: "Appointments", icon: Calendar },
    { id: "chatbot", label: "Symptoms", icon: MessageSquare },
    { id: "lab-reports", label: "Lab Reports", icon: FileText },
    { id: "reminders", label: "Reminders", icon: Bell },
    { id: "diary", label: "Health Diary", icon: BookOpen },
    { id: "connect-doctor", label: "Connect Doctor", icon: Mail },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 bg-gradient-to-r from-blue-600 to-blue-700 shadow-lg z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Heart className="w-8 h-8" />
            CARE CONNECT
          </h1>
          <Button variant="ghost" className="text-white hover:bg-blue-500" onClick={() => window.location.reload()}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                variant={currentPage === item.id ? "default" : "ghost"}
                className={`flex flex-col items-center gap-1 h-auto py-2 ${
                  currentPage === item.id ? "bg-white text-blue-600" : "text-white hover:bg-blue-500"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs text-center">{item.label}</span>
              </Button>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
