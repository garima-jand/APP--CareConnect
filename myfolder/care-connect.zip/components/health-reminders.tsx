"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Bell, Trash2, CheckCircle } from "lucide-react"

export default function HealthReminders() {
  const [reminders, setReminders] = useState([
    {
      id: 1,
      type: "Medication",
      message: "Take blood pressure medication",
      time: "08:00 AM",
      completed: false,
    },
    {
      id: 2,
      type: "Exercise",
      message: "30 minutes of walking",
      time: "06:00 PM",
      completed: true,
    },
    {
      id: 3,
      type: "Appointment",
      message: "Doctor appointment reminder",
      time: "10:00 AM",
      completed: false,
    },
  ])

  const [newReminder, setNewReminder] = useState({
    type: "Medication",
    message: "",
    time: "",
  })

  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault()
    if (newReminder.message && newReminder.time) {
      const reminder = {
        id: reminders.length + 1,
        type: newReminder.type,
        message: newReminder.message,
        time: newReminder.time,
        completed: false,
      }
      setReminders([...reminders, reminder])
      setNewReminder({ type: "Medication", message: "", time: "" })
    }
  }

  const toggleReminder = (id: number) => {
    setReminders(reminders.map((r) => (r.id === id ? { ...r, completed: !r.completed } : r)))
  }

  const deleteReminder = (id: number) => {
    setReminders(reminders.filter((r) => r.id !== id))
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Health Reminders</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Add Reminder Form */}
        <Card className="lg:col-span-1 p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Add Reminder</h3>
          <form onSubmit={handleAddReminder} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                value={newReminder.type}
                onChange={(e) => setNewReminder({ ...newReminder, type: e.target.value })}
              >
                <option value="Medication">Medication</option>
                <option value="Exercise">Exercise</option>
                <option value="Appointment">Appointment</option>
                <option value="Checkup">Checkup</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <Input
                type="text"
                placeholder="Reminder message"
                value={newReminder.message}
                onChange={(e) => setNewReminder({ ...newReminder, message: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
              <Input
                type="time"
                value={newReminder.time}
                onChange={(e) => setNewReminder({ ...newReminder, time: e.target.value })}
                required
              />
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Add Reminder
            </Button>
          </form>
        </Card>

        {/* Reminders List */}
        <div className="lg:col-span-2">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Your Reminders</h3>
          <div className="space-y-3">
            {reminders.map((reminder) => (
              <Card key={reminder.id} className={`p-4 ${reminder.completed ? "bg-gray-50" : ""}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <button onClick={() => toggleReminder(reminder.id)} className="mt-1">
                      <CheckCircle
                        className={`w-6 h-6 ${reminder.completed ? "text-green-600 fill-green-600" : "text-gray-300"}`}
                      />
                    </button>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Bell className="w-4 h-4 text-blue-600" />
                        <span className="text-xs font-semibold text-blue-600">{reminder.type}</span>
                      </div>
                      <p
                        className={`font-semibold ${reminder.completed ? "line-through text-gray-500" : "text-blue-900"}`}
                      >
                        {reminder.message}
                      </p>
                      <p className="text-sm text-gray-600">{reminder.time}</p>
                    </div>
                  </div>
                  <button onClick={() => deleteReminder(reminder.id)} className="text-red-600 hover:text-red-700">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
