"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, FileText, Bell, TrendingUp } from "lucide-react"

export default function Dashboard() {
  const stats = [
    { label: "Upcoming Appointments", value: "2", icon: Calendar, color: "bg-blue-100" },
    { label: "Lab Reports", value: "5", icon: FileText, color: "bg-cyan-100" },
    { label: "Health Reminders", value: "3", icon: Bell, color: "bg-teal-100" },
    { label: "Health Score", value: "85%", icon: TrendingUp, color: "bg-green-100" },
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-blue-900 mb-2">Welcome to CARE CONNECT</h2>
        <p className="text-gray-600">Your personal healthcare management platform</p>
      </div>

      {/* Hero Section with Hospital Image */}
      <div className="mb-8 rounded-lg overflow-hidden shadow-lg">
        <img src="/modern-hospital-healthcare-facility-with-doctors-a.jpg" alt="Healthcare facility" className="w-full h-64 object-cover" />
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                <Icon className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-gray-600 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-blue-900">{stat.value}</p>
            </Card>
          )
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Book an Appointment</Button>
            <Button className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">Find a Doctor</Button>
            <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white">Check Symptoms</Button>
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Recent Activity</h3>
          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between pb-2 border-b">
              <span className="text-gray-600">Appointment with Dr. Smith</span>
              <span className="text-blue-600 font-semibold">Today</span>
            </div>
            <div className="flex items-center justify-between pb-2 border-b">
              <span className="text-gray-600">Lab report uploaded</span>
              <span className="text-blue-600 font-semibold">2 days ago</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Health reminder set</span>
              <span className="text-blue-600 font-semibold">1 week ago</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
