"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, CheckCircle, AlertCircle } from "lucide-react"

export default function DoctorConnection() {
  const [connections, setConnections] = useState([
    {
      id: 1,
      email: "dr.smith@hospital.com",
      doctorName: "Dr. John Smith",
      specialty: "General Practice",
      status: "Connected",
      connectedDate: "2025-10-20",
    },
  ])

  const [newConnection, setNewConnection] = useState({
    email: "",
  })

  const [message, setMessage] = useState("")

  const handleConnectDoctor = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newConnection.email) {
      setMessage("Please enter a valid email address")
      return
    }

    // Check if already connected
    if (connections.some((c) => c.email === newConnection.email)) {
      setMessage("This doctor is already connected")
      return
    }

    const connection = {
      id: connections.length + 1,
      email: newConnection.email,
      doctorName:
        "Dr. " +
        newConnection.email.split("@")[0].split(".")[1].charAt(0).toUpperCase() +
        newConnection.email.split("@")[0].split(".")[1].slice(1),
      specialty: "Specialist",
      status: "Pending",
      connectedDate: new Date().toISOString().split("T")[0],
    }

    setConnections([...connections, connection])
    setNewConnection({ email: "" })
    setMessage("Connection request sent! Awaiting doctor approval.")

    setTimeout(() => setMessage(""), 3000)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Connect with Doctors</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Connection Form */}
        <Card className="lg:col-span-1 p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Add Doctor Connection</h3>
          <form onSubmit={handleConnectDoctor} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Doctor Email</label>
              <Input
                type="email"
                placeholder="doctor@hospital.com"
                value={newConnection.email}
                onChange={(e) => setNewConnection({ ...newConnection, email: e.target.value })}
                required
              />
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              <Mail className="w-4 h-4 mr-2" />
              Send Connection Request
            </Button>

            {message && (
              <div
                className={`p-3 rounded text-sm ${
                  message.includes("already") || message.includes("Please")
                    ? "bg-red-100 text-red-700"
                    : "bg-green-100 text-green-700"
                }`}
              >
                {message}
              </div>
            )}
          </form>

          <div className="mt-6 p-4 bg-blue-100 rounded-lg">
            <p className="text-sm text-blue-900">
              <strong>How it works:</strong> Enter your doctor's email address to send a connection request. Once
              approved, you can share your health records and communicate directly.
            </p>
          </div>
        </Card>

        {/* Connections List */}
        <div className="lg:col-span-2">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Your Doctor Connections</h3>
          <div className="space-y-4">
            {connections.length === 0 ? (
              <Card className="p-6 text-center text-gray-600">
                <Mail className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p>No doctor connections yet. Add one to get started!</p>
              </Card>
            ) : (
              connections.map((connection) => (
                <Card key={connection.id} className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-bold text-blue-900">{connection.doctorName}</h4>
                      <p className="text-sm text-gray-600">{connection.specialty}</p>
                      <p className="text-xs text-gray-500 mt-1">{connection.email}</p>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 ${
                        connection.status === "Connected"
                          ? "bg-green-100 text-green-700"
                          : "bg-yellow-100 text-yellow-700"
                      }`}
                    >
                      {connection.status === "Connected" ? (
                        <CheckCircle className="w-3 h-3" />
                      ) : (
                        <AlertCircle className="w-3 h-3" />
                      )}
                      {connection.status}
                    </span>
                  </div>

                  <div className="text-xs text-gray-600">
                    Connected on: {new Date(connection.connectedDate).toLocaleDateString()}
                  </div>

                  {connection.status === "Connected" && (
                    <div className="mt-3 pt-3 border-t">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm">Send Message</Button>
                    </div>
                  )}
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
