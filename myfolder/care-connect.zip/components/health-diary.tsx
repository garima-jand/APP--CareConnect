"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, Calendar } from "lucide-react"

export default function HealthDiary() {
  const [entries, setEntries] = useState([
    {
      id: 1,
      date: "2025-10-24",
      notes: "Feeling great today! Had a good workout and healthy meals.",
      mood: "Happy",
    },
    {
      id: 2,
      date: "2025-10-23",
      notes: "Slight headache in the afternoon. Drank plenty of water.",
      mood: "Okay",
    },
  ])

  const [newEntry, setNewEntry] = useState({
    date: new Date().toISOString().split("T")[0],
    notes: "",
    mood: "Okay",
  })

  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault()
    if (newEntry.notes) {
      const entry = {
        id: entries.length + 1,
        date: newEntry.date,
        notes: newEntry.notes,
        mood: newEntry.mood,
      }
      setEntries([entry, ...entries])
      setNewEntry({
        date: new Date().toISOString().split("T")[0],
        notes: "",
        mood: "Okay",
      })
    }
  }

  const deleteEntry = (id: number) => {
    setEntries(entries.filter((e) => e.id !== id))
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">Health Diary</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* New Entry Form */}
        <Card className="lg:col-span-1 p-6 bg-gradient-to-br from-blue-50 to-cyan-50">
          <h3 className="text-xl font-bold text-blue-900 mb-4">New Entry</h3>
          <form onSubmit={handleAddEntry} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
              <Input
                type="date"
                value={newEntry.date}
                onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mood</label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                value={newEntry.mood}
                onChange={(e) => setNewEntry({ ...newEntry, mood: e.target.value })}
              >
                <option value="Happy">Happy</option>
                <option value="Okay">Okay</option>
                <option value="Sad">Sad</option>
                <option value="Stressed">Stressed</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
              <textarea
                placeholder="Write your health notes here..."
                value={newEntry.notes}
                onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md h-24 resize-none"
                required
              />
            </div>

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Save Entry
            </Button>
          </form>
        </Card>

        {/* Entries List */}
        <div className="lg:col-span-2">
          <h3 className="text-xl font-bold text-blue-900 mb-4">Your Entries</h3>
          <div className="space-y-4">
            {entries.map((entry) => (
              <Card key={entry.id} className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="font-semibold text-blue-900">
                        {new Date(entry.date).toLocaleDateString("en-US", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </p>
                      <span className="text-xs font-semibold text-blue-600">Mood: {entry.mood}</span>
                    </div>
                  </div>
                  <button onClick={() => deleteEntry(entry.id)} className="text-red-600 hover:text-red-700">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                <p className="text-gray-700 leading-relaxed">{entry.notes}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
